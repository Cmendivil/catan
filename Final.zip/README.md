# catan
Final project for csci-3010<br/>  Build and Run by clicking the run button in QT
